<!-- Page header -->
<div class="page-header page-header-default">
	
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="#"><i class="icon-home2 position-left"></i> Home</a></li>
			
			<li class="active">Edit Profile</li>
		</ul>

		
	</div>
</div>
<!-- /page header -->
<!-- Content area -->
<div class="content">
	<?php if($this->session->flashdata('message') == 'update_success') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			Profile Successfully Updated.. 
		</div>
	<?php } ?>
	<!-- Form horizontal -->
	<div class="panel panel-flat">
		<div class="panel-heading">
			<div class="heading-elements">
				<ul class="icons-list">
					<li><a data-action="collapse"></a></li>
					<li><a data-action="reload"></a></li>
					<li><a data-action="close"></a></li>
				</ul>
			</div>
		</div>
		<div class="panel-body">
			<form class="form-horizontal" action="<?= base_url('admin/update_profile') ?>" method="post" enctype="multipart/form-data">
				<fieldset class="content-group">
					<legend class="text-bold">Edit Profile</legend>
					<div class="form-group">
						<label class="control-label col-lg-2">Username</label>
						<div class="col-lg-10">
							<input type="text" class="form-control" name="username" value="<?= $profile->username ?>">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-lg-2">Password</label>
						<div class="col-lg-10">
							<input type="password" class="form-control" name="password" value="<?= $profile->password ?>">
						</div>
					</div>
					<div class="form-group">
						<label class="control-label col-lg-2">Email</label>
						<div class="col-lg-10">
							<input type="email" class="form-control" name="email" value="<?= $profile->email ?>">
						</div>
					</div>
				</fieldset>
				<div class="text-right">
					<button type="submit" class="btn btn-primary">Edit <i class="icon-arrow-right14 position-right"></i></button>
				</div>
			</form>
		</div>
	</div>
	<!-- /form horizontal -->
</div>