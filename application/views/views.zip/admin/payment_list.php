<!-- Page header -->
<div class="page-header page-header-default">
	<div class="page-header-content">
		<div class="page-title">
			<h4>
				<i class="icon-lan2 position-left"></i>
				<span class="text-semibold"><?= $title ?></span>
				<button type="button" class="btn btn-primary btn-sm pull-right" onclick="add()">New&nbsp;Payment&nbsp;<i class="icon-lan2 position-right"></i></button>
			</h4>
		</div>
	</div>

	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?= base_url('welcome/consultantdashboard') ?>"><i class="icon-home2 position-left"></i>Home</a></li>
			<li><a href="#"><?= $title ?></a></li>
		</ul>
	</div>
</div>
<!-- /page header -->
<!-- Content area -->
<div class="content">

</div>

<script>
	function add() {
		location.href = '<?= base_url('admin/payment/add')?>';
	}
</script>