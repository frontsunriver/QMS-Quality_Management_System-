<!-- Page header -->
<div class="page-header page-header-default">
	
	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="#"><i class="icon-home2 position-left"></i> Home</a></li>
			
			<li class="active">Default Logo</li>
		</ul>

		
	</div>
</div>
<!-- /page header -->
<!-- Content area -->
<div class="content">
	<?php if($this->session->flashdata('message') == 'update_success') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			Default Logo Successfully Updated.. 
		</div>
	<?php } ?>
	<!-- Form horizontal -->
	<div class="panel panel-flat">
		<div class="panel-heading">
			<div class="heading-elements">
				<ul class="icons-list">
					<li><a data-action="collapse"></a></li>
					<li><a data-action="reload"></a></li>
					<li><a data-action="close"></a></li>
				</ul>
			</div>
		</div>
		<div class="panel-body">
			<form class="form-horizontal" action="<?= base_url('admin/update_default') ?>" method="post" enctype="multipart/form-data">
				<fieldset class="content-group">
					<legend class="text-bold">Default Logo</legend>
					<div class="form-group">
						<label class="control-label col-lg-2">Default Logo</label>
						<div class="col-lg-10">
							<img src="<?= base_url(UPLOAD_URL . "logo/{$logo->logo}") ?>" style="margin-bottom: 10px; height: 84px;">
							<input type="file" class="form-control" name="picture" >
						</div>
					</div>
				</fieldset>
				<div class="text-right">
					<button type="submit" class="btn btn-primary">Update</button>
				</div>
			</form>
		</div>
	</div>
	<!-- /form horizontal -->
</div>
<!-- /content area -->