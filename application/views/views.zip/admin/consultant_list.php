<!-- Page header -->
<div class="page-header page-header-default">
	<div class="page-header-content">
		<div class="page-title">
			<h4><i class="icon-lan2 position-left"></i> 
				<span class="text-semibold"><?= $title ?></span>
				<button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#modal_theme_primary_add">
					New Company <i class="icon-lan2 position-right"></i></button>
			</h4>
		</div>
	</div>

	<div class="breadcrumb-line">
		<ul class="breadcrumb">
			<li><a href="<?= base_url('welcome/consultantdashboard') ?>"><i class="icon-home2 position-left"></i>Home</a></li>
			<li><a href="#"><?= $title ?></a></li>
		
		</ul>
	</div>
</div>
<!-- Page header -->

<!-- Content area -->
<div class="content">
	<?php if($this->session->flashdata('message') == 'success') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			<span class="text-semibold">Thank you!</span>Plan Successfully created.. 
		</div>
	<?php } ?>

	<?php if($this->session->flashdata('message') == 'failed') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			<span class="text-semibold">Oppps!</span>Something Went Wrong Please try again.
		</div>
	<?php } ?>
	<?php if($this->session->flashdata('message') == 'success_del') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			Company Successfully Deleted..
		</div>
	<?php } ?>
	<?php if($this->session->flashdata('message') == 'update_success') { ?>
		<div class="alert alert-styled-right alert-styled-custom alert-arrow-right alpha-teal alert-bordered">
			<button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
			Company Successfully Updated..
		</div>
	<?php } ?>
	<!-- Basic datatable -->
	<div class="panel panel-flat" style="overflow: auto;">
		<table class="table datatable-basic">
			<thead>
				<tr>
					<th>No</th>
					<th>Username</th>
					<th>Company Name</th>
					<th>Plan Name</th>
					<th>Max accounts</th>
					<th>Pending Invoice</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php
				$cnt = 1;
				foreach ($consultants as $item) :
				?>
					<tr>
						<td><?= $cnt ++ ?></td>
						<td><?= $item->username ?></td>
						<td><?= $item->consultant_name ?></td>
						<td> <?= $item->plan_name ?></td>
						<td> <?= $item->no_of_user ?></td>
						<td>
							<?php
							if($item->plan_type == 'trial')
								echo 'Trial';
							else if($item->expired != '')
								echo 'Will be paid in ' . $item->expired;
							else
								echo 'Trial';
							?>
						</td>

						<td>
							<ul class="icons-list">
								<li class="text-primary-600" onclick="edit(<?= $item->consultant_id ?>);"><a href="#"><i class="icon-pencil7"></i></a></li>
								<li class="text-danger-600"><a href="#" id="<?= $item->consultant_id ?>" class="delete" ><i class="icon-trash"></i></a></li>
							</ul>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
	<!-- Basic datatable -->
</div>

<!-- Primary modal -->
<div id="modal_theme_primary1" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-home2 position-right"></i> Edit  Company</h6>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('admin/edit_consultant') ?>"  method="post">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Company Name: </label>
								<input type="text" placeholder="Company Name" required class="form-control" name="consultant_name" id="consultant_name" />
								<div class="form-control-feedback">
									<i class="icon-list text-muted"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Username: </label>
								<input type="text" placeholder="Username" required  class="form-control" name="username" id="username">
								<div class="form-control-feedback">
									<i class="icon-user text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Email: </label>
								<input type="email"  class="form-control" name="email" id="email" placeholder="Email">
								<div class="form-control-feedback">
									<i class="icon-inbox text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Password: </label>
								<input type="password" class="form-control" required  name="password" id="password" placeholder="Password">
								<input type="hidden"  class="form-control" name="consultant_id11" id="consultant_id11">
								<div class="form-control-feedback">
									<i class="icon-key text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Plan: </label>
								<select name="plan" id="edit_plan_id1" required class="form-control">
									<option value="">--Select Plan--</option>
									<?php
									if(!empty($plan)) {
										foreach($plan as $idx => $plan_rec) { ?>
											<option value="<?= $plan_rec['plan_id'];?>"><?= $plan_rec['plan_name'];?></option>
									<?php } }?>
								</select>
								<!--<input type="text" placeholder="Plan" class="form-control" name="plan" id="plan">-->
								<div class="form-control-feedback">
									<i class="icon-list text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Expired Date: </label>
								<input type="text" class="form-control" required name="expired_date" id="expired_date" placeholder="Expired Date">
								<div class="form-control-feedback">
									<i class="icon-calendar text-muted"></i>
								</div>
							</div>
						</div>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary"><i class="icon-plus2 position-right"></i> Edit</button>
			</div>
			</form>
		</div>
	</div>
</div>
<!-- /primary modal -->
<div id="modal_theme_primary_add" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header bg-primary">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h6 class="modal-title"><i class="icon-home2 position-right"></i> Add  Company</h6>
			</div>
			<div class="modal-body">
				<form action="<?= base_url('admin/add_consultant') ?>"  method="post">
					<div class="row">
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Company Name: </label>
								<input type="text" placeholder="Company Name" required  class="form-control" name="consultant_name" />
								<div class="form-control-feedback">
									<i class="icon-list text-muted"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Username: </label>
								<input type="text" placeholder="Username" required class="form-control" name="username" />
								<div class="form-control-feedback">
									<i class="icon-user text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Email: </label>
								<input type="email"  class="form-control" name="email"  placeholder="Email">
								<div class="form-control-feedback">
									<i class="icon-inbox text-muted"></i>
								</div>
							</div>
						</div>
					</div>
					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Password: </label>
								<input type="password" class="form-control" required  name="password"  placeholder="Password">
								<!--<input type="hidden"  class="form-control" name="consultant_id11" id="consultant_id11">-->
								<div class="form-control-feedback">
									<i class="icon-key text-muted"></i>
								</div>
							</div>
						</div>
					</div>

					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Plan: </label>
								<select name="plan" id="plan_id1" required class="form-control">
									<option value="">--Select Plan--</option>
									<?php
									if(!empty($plan))
									{
										foreach($plan as $idx => $plan_rec)
										{
											?>
											<option value="<?= $plan_rec['plan_id'];?>"><?= $plan_rec['plan_name'];?></option>
											<?php
										}
									}?>
								</select>
								<!--<input type="text" placeholder="Plan" class="form-control" name="plan" id="plan">-->
							</div>
						</div>
					</div>

					<div class="row" >
						<div class="col-md-12">
							<div class="form-group has-feedback">
								<label>Expired Date: </label>
								<input type="text" required class="form-control" name="expired_date" id="add_expired_date" placeholder="Expired Date">
								<div class="form-control-feedback">
									<i class="icon-calendar text-muted"></i>
								</div>
							</div>
						</div>
					</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary"><i class="icon-plus2 position-right"></i> Add Owner</button>
			</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'pickers/datepicker.js') ?>"></script>
<script type="text/javascript">
	$('body').on('click','.delete' ,function(e){
		var id = $(this).attr('id');
		var dialog = bootbox.dialog({
			title: 'Confirmation',
			message: "<h4>Are You Sure want to delete ?</h4> <br><p>Warning ! you will be loss All records of deleted Company..</p>",
			size: 'small',
			buttons: {
				cancel: {
					label: "Cancel",
					className: 'btn-danger',
					callback: function(){
						dialog.modal('hide');
					}
				},

				ok: {
					label: "OK",
					className: 'btn-success',
					callback: function(){
						window.location.href="<?php echo base_url();?>index.php/Admin/delete_consultant/"+id;
					}
				}
			}
		});
	});
	var today = new Date();
	$('document').ready(function(e){
		$("#expired_date").datepicker({
			startDate : today,
		});

		$("#add_expired_date").datepicker({
			startDate : today,
		});

	});
</script>

<script type="text/javascript">
	function edit(val){
		$('#modal_theme_primary1').modal('show');
		$.ajax({
			type: "POST",
			url: "<?php echo base_url(); ?>index.php/Admin/findcomp",
			data:{ 'id' : val},
			success: function(data) {
				var datas = $.parseJSON(data);

				$("#consultant_id11").val(datas.consultant_id);
				$("#username").val(datas.username);
				$("#email").val(datas.email);
				$("#password").val(datas.password);
				$("#consultant_name").val(datas.consultant_name);
				$("#edit_plan_id1").val(datas.plan_id);
				$("#expired_date").val(datas.expired);
				var myDate = new Date(datas.expired);
				$('#expired_date').datepicker('setDate', myDate);
			}
		});
	}
</script>