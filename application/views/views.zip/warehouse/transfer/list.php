<style>
	td, th {
		text-align: center;
		word-break: keep-all !important;
	}
</style>

<div class="content">
	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title" style="display: inline-block;">Transfer</h5>
		</div>
		<table class="table table-ship">
            <thead>
                <tr>
                    <th>Reference</th>
                    <th>Scheduled Date</th>
                    <th>Supplier</th>
                    <th>Destination Location</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><a href="<?php echo base_url()?>warehouse/transfer/viewData/1">WH/OUT/00001</a></td>
                    <td>11/24/2018 04:10:52</td>
                    <td>Vendor Company-42bv232323/td>
                    <td>warehouse123</td>
                    <td>Awaiting Operation</td>
                </tr>
            </tbody>
        </table>
	</div>
</div>

<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/selects/bootstrap_select.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/validation/validate.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/datatables.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/fixed_columns.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/col_reorder.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/buttons.min.js') ?>"></script>

<script type="text/javascript" src="<?= base_url(JS_URL . 'user/warehouse/transfer/list.js') ?>"></script>