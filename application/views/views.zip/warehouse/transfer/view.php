<style>
    td, th {
        text-align: center;
        word-break: keep-all !important;
    }

    button {
        margin-right: 15px;
    }
</style>
<div class="content">
	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title" style="display: inline-block;">WH/OUT/00001</h5>
            <button type="button" class="btn bg-blue pull-right" onclick="">Done</button>
            <button type="button" class="btn bg-blue pull-right" onclick="">Download Pdf</button>
		</div>
        <div class="panel-body" >
            <div class="row" style="margin: 15px">
                <table class="col-sm-6">
                    <tr>
                        <td  style="width: 40%">Supplier</td>
                        <td  style="width: 60%; color: seagreen ">Vendor Company-42bv232323</td>
                    </tr>

                </table>
                <table class="col-sm-6">
                    <tr>
                        <td  style="width: 50%">Scheduled Date</td>
                        <td  style="width: 50%">11/19/2018 00:09:20</td>
                    </tr>
                    <tr>
                        <td>Effective Date</td>
                        <td>11/19/2018 00:09:20</td>
                    </tr>
                </table>
            </div>
            <div class="row" style="margin: 15px">
                <table class="col-sm-6">
                    <tr>
                        <td  style="width: 40%">Destination Location</td>
                        <td  style="width: 60%; color: seagreen ">WH/Stock</td>
                    </tr>

                </table>
            </div>


        </div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12">
					<div class="tabbable">
						<ul class="nav nav-tabs nav-tabs-top top-divided">
							<li class="active">
								<a href="#tab1" data-toggle="tab">Operations</a>
							</li>

						</ul>
						<div class="tab-content">
							<div id="tab1" class="tab-pane active">
								<table class="table table-operation">
                                    <thead>
                                    <tr>
                                        <th>Materials</th>
                                        <th>Initial Demand</th>
                                        <th>Done</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr style="color: lightgrey">
                                        <td>[Internal Reference] Product1</td>
                                        <td>1.000</td>
                                        <td>1.000</td>
                                    </tr>
                                    </tbody>
                                </table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>


<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/selects/bootstrap_select.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/validation/validate.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/datatables.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/fixed_columns.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/col_reorder.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/buttons.min.js') ?>"></script>

<script type="text/javascript" src="<?= base_url(JS_URL . 'user/warehouse/transfer/view.js') ?>"></script>