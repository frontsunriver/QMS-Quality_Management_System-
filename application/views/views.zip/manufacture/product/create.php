<style>
	.dropzone {
		min-height: 175px;
	}
	.dropzone .dz-default.dz-message {
	    height: 175px;
	}
	.mb-3, .my-3 {
		margin-bottom: 0px !important;
	}
</style>

<div class="content">
	<div class="panel panel-flat">
		<div class="panel-heading" style="border-bottom: 1px solid #eee;">
			<h5 class="panel-title" style="display: inline-block;">&nbsp;</h5>
			<button type="submit" class="btn btn-primary pull-right" onclick="javascript:onCreate();">Create</button>
		</div>
		<div class="container-fluid">
			<form id="add_form" action="<?= base_url('manufacture/product/create') ?>" method="post" enctype="multipart/form-data">
				<div class="form-group">
					<div class="row">
						<div class="col-sm-8">
							<h3 style="margin-top: 0px;">Product Name</h3>
							<input type="text" class="form-control col-md-8" style="margin-bottom: 5px;" placeholder="" name="create[name]" value="">
							<div class="checkbox">
								<label>
									<input type="checkbox" class="control-success" checked="checked">
									Can be Sold
								</label>
							</div>
							<div class="checkbox">
								<label>
									<input type="checkbox" class="control-success" checked="checked">
									Can be Purchased
								</label>
							</div>
						</div>
						<div class="col-sm-4">
							<div id="product_img" action="#" class="dropzone"></div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="tabbable">
								<ul class="nav nav-tabs nav-tabs-top top-divided">
									<li class="active">
										<a href="#tab1" data-toggle="tab">General Information</a>
									</li>
									<li>
										<a href="#tab2" data-toggle="tab">Variants</a>
									</li>
									<li>
										<a href="#tab3" data-toggle="tab">Sales</a>
									</li>
									<li>
										<a href="#tab4" data-toggle="tab">Purchase</a>
									</li>
									<li>
										<a href="#tab5" data-toggle="tab">Inventory</a>
									</li>
								</ul>
								<div class="tab-content">
									<div id="tab1" class="tab-pane active">
										<div class="row">
											<div class="col-lg-6 form-group">
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Product Type</label>
													<div class="col-lg-6">
														<select class="form-control mb-3">
															<option>Storable Product</option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Product Category</label>
													<div class="col-lg-6">
														<select class="form-control mb-3">
															<option>All</option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Internal Reference</label>
													<div class="col-lg-6">
														<input type="text" class="form-control">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Barcode</label>
													<div class="col-lg-6">
														<input type="text" class="form-control">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Version</label>
													<div class="col-lg-6">
														<input type="number" class="form-control" value="1">
													</div>
												</div>
											</div>
											<div class="col-lg-6 form-group">
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Sales Price</label>
													<div class="col-lg-6">
														<input type="number" class="form-control" value="1">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Customer Taxes</label>
													<div class="col-lg-6">
														<select class="form-control mb-3">
															<option>Tax 15.00%</option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">TaxCloud Category</label>
													<div class="col-lg-6">
														<select class="form-control mb-3">
															<option></option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-4 control-label text-lg-right pt-2">Cost</label>
													<div class="col-lg-6">
														<input type="number" class="form-control" value="">
													</div>
												</div>
											</div>
										</div>
										<div class="row col-lg-9" style="margin-left: auto; margin-right: auto;">
											<label class="col-lg-4 control-label pt-2"><h3 style="margin-top: 0px; margin-bottom: 0px;">Internal Notes</h3></label>
											<div class="col-lg-12">
												<textarea class="col-lg-12"></textarea>
											</div>
										</div>
									</div>
									<div id="tab2" class="tab-pane">
										<p>Variants</p>
									</div>
									<div id="tab3" class="tab-pane">
										<p>Sales</p>
									</div>
									<div id="tab4" class="tab-pane">
										<p>Purchase</p>
									</div>
									<div id="tab5" class="tab-pane">
										<p>Inventory</p>
									</div>
								</div>
								<br/>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/styling/uniform.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'uploaders/dropzone.min.js') ?>"></script>

<script type="text/javascript" src="<?= base_url(JS_URL . 'user/manufacture/product/create.js') ?>"></script>