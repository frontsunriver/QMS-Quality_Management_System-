<input type="hidden" name="id" value="<?= !$category ? -1 : $category->id ?>" />

<div class="form-group">
    <div class="row">
        <div class="col-sm-6">
            <label>Name</label>
            <input type="text" class="form-control" placeholder="" name="add[name]" value="<?= !$category ? '' : $category->name ?>">
        </div>
        <div class="col-sm-6">
            <label>Description</label>
            <input type="text" class="form-control" placeholder="" name="add[description]" value="<?= !$category ? '' : $category->description ?>">
        </div>
    </div>
</div>