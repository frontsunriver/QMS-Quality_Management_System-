<style>
	#tab2 th {
		font-weight: 700;
		font-size: 15px;
	}
	#tab2 table td > a {
		display: table-caption;
		margin-bottom: 3px;
	}
</style>

<div class="content col-md-8" style="margin-left: auto; margin-right: auto;">
	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title" style="display: inline-block;">Product Planing Management</h5>
			<button type="button" class="btn bg-blue pull-right" data-toggle="modal" data-target="#modal_save">ADD</button>
		</div>
		<div class="container-fluid">
			<div class="row">
				<div class="col-sm-12">
					<div class="tabbable">
						<ul class="nav nav-tabs nav-tabs-top top-divided">
							<li class="active">
								<a href="#tab1" data-toggle="tab">By Frequency</a>
							</li>
							<li>
								<a href="#tab2" data-toggle="tab">By Calendar</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="tab1" class="tab-pane active">
								<table class="table datatable-product"></table>
							</div>
							<div id="tab2" class="tab-pane">
								<table class="table table-responsive-md  mb-0 table-bordered">
									<tr>
										<th rowspan="2" width="20%" class="center">Name of Programme</th>
										<th rowspan="2" width="5%" class="center">Duration</th>
										<th colspan="12" width="75%" class="center">Date of Programme</th>
									</tr>
									<tr>
										<?php
											$current_month = intval(date("m"));
											for ($i = 0; $i < 8; $i ++) {
												switch ($current_month){
												case 1:
													echo "<th>Jan</th>";
													break;
												case 2:
													echo "<th>Feb</th>";
													break;
												case 3:
													echo "<th>March</th>";
													break;
												case 4:
													echo "<th>April</th>";
													break;
												case 5:
													echo "<th>May</th>";
													break;
												case 6:
													echo "<th>June</th>";
													break;
												case 7:
													echo "<th>July</th>";
													break;
												case 8:
													echo "<th>Aug</th>";
													break;
												case 9:
													echo "<th>Sept</th>";
													break;
												case 10:
													echo "<th>Oct</th>";
													break;
												case 11:
													echo "<th>Nov</th>";
													break;
												case 12:
													echo "<th>Dec</th>";
													break;
												}
												$current_month ++;
												if ($current_month > 12)
													$current_month = $current_month - 12;
											}
										?>
									</tr>
									<tr>
										<td><a href="">ABC</a></td>
										<td>1</td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">9-10 :123</a>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">9-10 :123</a>
										</td>
										<td></td>
										<td></td>
										<td></td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">2-3 :111</a>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">2-3 :111</a>
										</td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td><a href="">Sample</a></td>
										<td>1</td>
										<td>
										</td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-2 :a1</a>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-2 :a1</a>
										</td>
										<td></td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-2 :City</a>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-2 :City</a>
										</td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td><a href="">Training</a></td>
										<td>1</td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-3 :X</a>
										</td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
									</tr>
									<tr>
										<td><a href="">Check Error</a></td>
										<td>1</td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td>
											<a class="btn btn-xs btn-primary " href="" style="font-size: 8px; color: white">1-2 :123</a>
										</td>
										<td></td>
									</tr>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="modal_save" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title">Add Product Planing</h5>
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<form id="add_form">
				<div class="modal-body">
				</div>
				<div class="modal-footer">
					<button type="submit" class="btn bg-blue">Save</button>
					<button type="button" class="btn btn-link" data-dismiss="modal">Close</button>
				</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/selects/bootstrap_select.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/validation/validate.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/datatables.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/fixed_columns.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/col_reorder.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'tables/datatables/extensions/buttons.min.js') ?>"></script>

<script type="text/javascript" src="<?= base_url(JS_URL . 'user/manufacture/plan/list_product.js') ?>"></script>