<style>
	.no-margin-bottom {
		margin-bottom: 0px !important;
	}
	h3 {
		margin-top: 0px;
		color: lightseagreen;
	}
</style>

<div class="content col-md-8" style="margin-left: auto; margin-right: auto;">
	<div class="panel panel-flat">
		<div class="panel-heading">
			<h5 class="panel-title" style="display: inline-block;">View Work Orders</h5>
			<div class="pull-right">
				<button type="button" class="btn bg-blue" onclick="">Start</button>
				<button type="button" class="btn bg-blue" onclick="">Cancel</button>
			</div>
		</div>
		<div class="container-fluid">
			<div class="row col-lg-12">
				<div class="col-lg-6 form-group">
					<div class="form-group row no-margin-bottom">
						<label class="col-lg-5 control-label pt-2 text-bold">Product</label>
						<label class="col-lg-5 control-label pt-2">Assembly - Table</label>
					</div>
					<div class="form-group row no-margin-bottom">
						<label class="col-lg-5 control-label pt-2 text-bold">Manufacturing Order</label>
						<label class="col-lg-5 control-label pt-2 text-mute">MO00011</label>
					</div>
					<div class="form-group row no-margin-bottom">
						<label class="col-lg-4 control-label pt-2 text-bold">Sequence</label>
						<label class="col-lg-5 control-label pt-2">0</label>
					</div>
				</div>
				<div class="col-lg-6 form-group">
					<div class="form-group row no-margin-bottom">
						<label class="col-lg-5 control-label pt-2 text-bold">Work Center</label>
						<label class="col-lg-5 control-label pt-2 text-mute">Table assembly</label>
					</div>
					<div class="form-group row no-margin-bottom">
						<label class="col-lg-5 control-label pt-2 text-bold">Production Status</label>
						<label class="col-lg-5 control-label pt-2">Ready to Produce</label>
					</div>
				</div>
			</div>
			<div class="row form-group">
				<div class="col-sm-12">
					<div class="tabbable">
						<ul class="nav nav-tabs nav-tabs-top top-divided">
							<li class="active">
								<a href="#tab1" data-toggle="tab">Information</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="tab1" class="tab-pane active">
								<div class="row col-lg-12">
									<div class="col-lg-6 form-group">
										<h3>Planned Date</h3>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Scheduled Date</label>
											<label class="col-lg-5 control-label pt-2">09/17/2014 16:56:17</label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">End Date</label>
											<label class="col-lg-5 control-label pt-2 text-mute">09/17/2014 16:56:17</label>
										</div>
									</div>
									<div class="col-lg-6 form-group">
										<h3>Duration</h3>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Number of Cycles</label>
											<label class="col-lg-5 control-label pt-2 text-mute">1.00</label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Number of Hours</label>
											<label class="col-lg-5 control-label pt-2">06:00</label>
										</div>
									</div>
								</div>
								<div class="row col-lg-12">
									<div class="col-lg-6 form-group">
										<h3>Actual Production Date</h3>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Start Date</label>
											<label class="col-lg-5 control-label pt-2"></label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">End Date</label>
											<label class="col-lg-5 control-label pt-2 text-mute"></label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Working Hours</label>
											<label class="col-lg-5 control-label pt-2 text-mute">00:00</label>
										</div>
									</div>
									<div class="col-lg-6 form-group">
										<h3>Product to Produce</h3>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Product</label>
											<label class="col-lg-5 control-label pt-2 text-mute">Table</label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Qty</label>
											<label class="col-lg-5 control-label pt-2">1.00</label>
										</div>
										<div class="form-group row no-margin-bottom">
											<label class="col-lg-5 control-label pt-2 text-bold">Unit of Measure</label>
											<label class="col-lg-5 control-label pt-2">Unit($)</label>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>