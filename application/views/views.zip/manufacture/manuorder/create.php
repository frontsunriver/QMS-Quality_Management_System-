<style>
	.mb-3, .my-3 {
		margin-bottom: 0px !important;
	}
</style>

<div class="content col-md-8" style="margin-left: auto; margin-right: auto;">
	<div class="panel panel-flat">
		<div class="panel-heading" style="padding-bottom: 0px;">
			<h5 class="panel-title" style="display: inline-block;">Create Manufacturing Orders</h5>
			<div class="pull-right">
				<button type="button" class="btn bg-blue" onclick="javascript:onSave();">Save</button>
				<button type="button" class="btn bg-blue" onclick="javascript:onBack();">Back</button>
			</div>
		</div>
		<div class="container-fluid" style="padding-right: 6px;">
			<div class="row col-md-12" style="padding-right: 0px;">
				<form class="form-control">
					<div class="row form-group">
						<div class="col-lg-6 form-group">
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Product</label>
								<div class="col-lg-6">
									<select class="form-control mb-3" name="create[product]">
										<option>Table</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Product Quantity</label>
								<div class="col-lg-6">
									<input type="text" class="form-control mb-3 col-lg-7" name="create[product]" value="1.00">
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Scheduled Date</label>
								<div class="col-lg-6">
									<input type="date" class="form-control mb-3" name="create[product]" value="">
								</div>
							</div>
						</div>
						<div class="col-lg-6 form-group">
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Bill of Material</label>
								<div class="col-lg-6">
									<select class="form-control mb-3" name="create[product]">
										<option>Table</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Routing</label>
								<div class="col-lg-6">
									<select class="form-control mb-3 col-lg-8" name="create[product]">
										<option>Table</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Responsible</label>
								<div class="col-lg-6">
									<select class="form-control mb-3" name="create[product]">
										<option>Manager Odoo</option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<div class="col-lg-1"></div>
								<label class="col-lg-4 control-label pt-2">Product Quantity</label>
								<div class="col-lg-6">
									<input class="form-control mb-3" name="create[product]" value="1.00">
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
			<br />
			<div class="row form-group col-sm-12">
				<button type="button" class="btn btn-danger">Confirm Production</button>
			</div>
			<div class="row form-group">
				<div class="col-sm-12" style="padding-right: 30px;">
					<div class="tabbable">
						<ul class="nav nav-tabs nav-tabs-top top-divided">
							<li class="active">
								<a href="#tab1" data-toggle="tab">Consumed Product</a>
							</li>
							<li>
								<a href="#tab2" data-toggle="tab">Finished Products</a>
							</li>
							<li>
								<a href="#tab3" data-toggle="tab">Work Orders</a>
							</li>
							<li>
								<a href="#tab4" data-toggle="tab">Scheduled Products</a>
							</li>
							<li>
								<a href="#tab5" data-toggle="tab">Extra Information</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="tab1" class="tab-pane active">
								<div class="row">
										<div class="col-lg-6 form-group">
											<label class="text-bold">
												Material to Consume
											</label>
											<hr style="margin: 0 0 10px 0;" />
											<div class="form-group row col-lg-12">
												<table class="table">
													<thead>
														<tr style="background-color: #e8f5e9;">
															<th>Material</th>
															<th>Quantity</th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td>Wood Panel 300</td>
															<td>1.000</td>
														</tr>
														<tr>
															<td>Leg</td>
															<td>4.000</td>
														</tr>
														<tr>
															<td colspan="2" style="padding-top: 5px;">
																<button type="button" class="btn btn-xs bg-blue">Add an item</button>
															</td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
										<div class="col-lg-6 form-group">
											<label class="text-bold">
												Consumed Material
											</label>
											<hr style="margin: 0 0 10px 0;" />
											<div class="form-group row col-lg-12">
												<table class="table">
													<thead>
														<tr style="background-color: #e8f5e9;">
															<th>Material</th>
															<th>Lot</th>
															<th>Quantity</th>
														</tr>
													</thead>
													<tbody>
														<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
														<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<div id="tab2" class="tab-pane"></div>
								<div id="tab3" class="tab-pane">
									<div class="col-lg-12 form-group">
											<button type="button" class="btn btn-sm bg-blue"><i class="icon-calculator2"></i>&nbsp;Compute Data</button>
											<hr style="margin: 5px 0 10px 0;" />
											<div class="form-group row col-lg-12">
												<table class="table">
													<thead>
														<tr style="background-color: #e8f5e9;">
															<th>Sequence</th>
															<th>Work Order</th>
															<th>Work Center</th>
															<th>Number of Cycles</th>
															<th>Number of Hours</th>
															<th>Status</th>
															<th></th>
														</tr>
													</thead>
													<tbody>
														<tr>
															<td align="right">0</td>
															<td>Assembly - Table</td>
															<td>Table assembly</td>
															<td>1.00</td>
															<td>06.00</td>
															<td><i class="icon-play3" style="cursor: pointer;" onclick="location.href = base_url + 'manufacture/workorder/view/1';"></i></td>
														</tr>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
								<div id="tab4" class="tab-pane"></div>
								<div id="tab5" class="tab-pane"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>