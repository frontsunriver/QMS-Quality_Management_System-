<style>
	.mb-3, .my-3 {
		margin-bottom: 0px !important;
	}
</style>

<div class="content">
	<div class="panel panel-flat">
		<div class="panel-heading" style="border-bottom: 1px solid #eee;">
			<button type="submit" class="btn btn-primary" onclick="javascript:onCreate();">Create</button>
			<div class="pull-right">
				<div class="checkbox checkbox-switch">
					<input type="checkbox" data-on-color="danger" data-off-color="primary" data-on-text="Active" data-off-text="Deactive" class="switch" checked="checked">
				</div>
			</div>
		</div>
		<div class="container-fluid">
			<form id="add_form" action="<?= base_url('manufacture/bill/create') ?>" method="post">
				<div class="form-group">
					<div class="row">
						<div class="col-lg-6 form-group">
							<div class="form-group row">
								<label class="col-lg-4 control-label text-lg-right pt-2">Product</label>
								<div class="col-lg-6">
									<select class="form-control mb-3" name="create[product]">
										<option></option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-lg-4 control-label text-lg-right pt-2">Product Variants</label>
								<div class="col-lg-6">
									<select class="form-control mb-3">
										<option></option>
									</select>
								</div>
							</div>
							<div class="form-group row">
								<label class="col-lg-4 control-label text-lg-right pt-2">Quantity</label>
								<div class="col-lg-6">
									<input type="number" class="form-control" value="1">
								</div>
							</div>
						</div>
						<div class="col-lg-6 form-group">
							<div class="form-group row">
								<label class="col-lg-4 control-label text-lg-right pt-2">Reference</label>
								<div class="col-lg-6">
									<input type="text" class="form-control">
								</div>
							</div>
							<div class="form-group row">
								<label class="col-lg-4 control-label text-lg-right pt-2">BoM Type</label>
								<div class="col-lg-6" style="margin-top: 10px;">
									<div class="radio">
										<label>
											<input type="radio" name="radio-styled-color" class="control-success" checked="checked">
											Manufacture this product
										</label>
									</div>
									<div class="radio">
										<label>
											<input type="radio" name="radio-styled-color" class="control-success">
											Kit
										</label>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-12">
							<div class="tabbable">
								<ul class="nav nav-tabs nav-tabs-top top-divided">
									<li class="active">
										<a href="#tab1" data-toggle="tab">Material</a>
									</li>
									<li>
										<a href="#tab2" data-toggle="tab">Miscellaneous</a>
									</li>
								</ul>
								<div class="tab-content">
									<div id="tab1" class="tab-pane active">
										<div class="table-responsive">
											<table class="table">
												<thead>
													<tr style="background-color: #e8f5e9;">
														<th>Material</th>
														<th>Quantity</th>
														<th>Apply on Variants</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<tr>
														<td>component1</td>
														<td>1.000</td>
														<td></td>
														<td>
															<ul class="icons-list">
																<li><a href="#"><i class="icon-trash"></i></a></li>
															</ul>
														</td>
													</tr>
													<tr>
														<td colspan="4" style="padding-top: 5px;">
															<button type="button" class="btn btn-primary btn-xs">Add a line</button>
														</td>
													</tr>
												</tbody>
											</table>
										</div>
									</div>
									<div id="tab2" class="tab-pane"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/styling/uniform.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url(PLUGINS_URL . 'forms/styling/switch.min.js') ?>"></script>

<script type="text/javascript" src="<?= base_url(JS_URL . 'user/manufacture/bill/create.js') ?>"></script>