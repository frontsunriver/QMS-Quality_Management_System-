<input type="hidden" name="id" value="<?= !$routing ? -1 : $routing->id ?>" />

<div class="form-group">
    <div class="row">
        <div class="col-sm-6">
            <label>Code</label>
            <input type="text" class="form-control" placeholder="" name="add[code]" value="<?= !$routing ? '' : $routing->code ?>">
        </div>
        <div class="col-sm-6">
            <label>Name</label>
            <input type="text" class="form-control" placeholder="" name="add[name]" value="<?= !$routing ? '' : $routing->name ?>">
        </div>
    </div>
</div>
<div class="form-group">
    <div class="row">
        <div class="col-sm-6">
            <label>Production Location</label>
            <input type="text" class="form-control" name="add[product_location]" value="<?= !$routing ? '' : $routing->product_location ?>">
        </div>
        <div class="col-sm-6">
            <label>Activation</label>
            <select class="form-control" name="add[del_flag]">
                <option value="0" <?= !$routing || $routing->del_flag == 0 ? 'selected' : '' ?>>Active</option>
                <option value="1" <?= $routing && $routing->del_flag == 1 ? 'selected' : '' ?>>Deactive</option>
            </select>
        </div>
    </div>
</div>