<footer>
	<div class="container wow fadeIn">
		<div class="row Border_Top">
			<div class="col-sm-2 col-xs-2 col-md-2">
				<div class="Footer-Left">
					<img src="<?= base_url(IMG_URL . 'home/footer-logo.png') ?>" alt="" />
					<ul class="Social_Menu">
						<li><a href="https://www.facebook.com"><img src="<?= base_url(IMG_URL . 'home/facebook.png') ?>" alt=""></a></li>
						<li><a href="https://twitter.com"><img src="<?= base_url(IMG_URL . 'home/twitter.png') ?>" alt=""></a></li>
						<li><a href="https://www.youtube.com/"><img src="<?= base_url(IMG_URL . 'home/youtube.png') ?>" alt=""></a></li>
						<li><a href="https://www.instagram.com"><img src="<?= base_url(IMG_URL . 'home/instagram.png') ?>" alt=""></a></li>
					</ul>
					<span class="SubText">© Quality Circle, Inc. 2018</span>
				</div>
			</div>
			<div class="col-sm-4 col-xs-4 col-md-4">
				<h2 class="ftrTitle">Quick Links</h2>
				<ul class="Footer_Menu">
					<li><a href="index.html">Home </a></li>
					<li><a href="about-us.html">About Us </a></li>
					<li><a href="pricing.html">Pricing </a></li>
					<li><a href="">Smart Solutions </a></li>
					<li><a href="sign_up.html">Sign Up</a></li>
				</ul>
				<ul class="Footer_Menu">
					<li><a href="#">Verification Software</a></li>
					<li><a href="#">Gap Audit Software</a></li>
					<li><a href="#">Process Auditing Software</a></li>
					<li><a href="#">Contract Signing Software</a></li>
					<li><a href="#">Implementation Software</a></li>
					<li><a href="#">Virtual Academy</a></li>
				</ul>
			</div>
			<div class="col-sm-6 col-xs-6 col-md-6">
				<h2 class="ftrTitle">Office Location</h2>
				<div class="contactFtr">
					<h5>United States</h5>
					<div class="contactRow pinIcon">
						<p>1402 W. Marshall Ave.,<br/> Longview,<br/> Texas 75604.</p>
					</div>
					<div class="contactRow pinIcon">
						<p>P.O. Box 10135<br/>4501 McCann Rd.<br/>Longview,<br/> TX 75605</p>
					</div>
					<div class="contactRow phoneIcon">
						<p><strong>Phone</strong> 1-903-700-8111</p>
					</div>
				</div>
				<div class="contactFtr">
					<h5>Jamaica</h5>
					<div class="contactRow pinIcon">
						<p> The Trade Center Business <br/>Complex 30-32 Red Hills Road,<br/>Suite # 3A<br/>Kingston 10<br/>Jamaica</p>
					</div>
					<div class="contactRow pinIcon">
						<p> P.O. Box 190,<br/>Kingston 5,<br/>Jamaica W.I.</p>
					</div>
					<div class="contactRow phoneIcon">
						<p><strong>Phone</strong> 1-876-860-711</p>
					</div>
				</div>
			</div>
		</div>
	</div>	
</footer>

<script>
	new WOW().init();
</script>
</body>

</html>