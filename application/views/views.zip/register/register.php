<style>
	label {
		font-size: 13px;
	}

	.help-block > a {
		font-size: 12px;
	}

	.help-block > a:hover {
		box-shadow: none;
		transition: initial;
	}
	small > p {
		color: red;
		font-size: 14px;
		font-weight: bold;
	}
	.content-divider > span {
		background-color: white;
	}
</style>

<section class="LoginBox">
	<form class="wow zoomIn" action="<?= base_url('auth/register') ?>" method="post">
		<div class="login-form">
			<div class="text-center">
				<div class="icon-object border-warning-400 text-warning-400"><i class="icon-people"></i></div>
				<h5 class="content-group-lg">Create account
					<small class="display-block">
						<?= validation_errors() ?>
					</small>
				</h5>
			</div>
			<div class="form-group has-feedback has-feedback-left">
				<input type="text" class="form-control input-lg" placeholder="Company Name" name="register[consultant_name]">
				<div class="form-control-feedback">
					<i class="icon-home text-muted"></i>
				</div>
			</div>
			<div class="form-group has-feedback has-feedback-left">
				<input type="email" class="form-control input-lg" placeholder="Email" name="register[email]">
				<div class="form-control-feedback">
					<i class="icon-mail5 text-muted"></i>
				</div>
			</div>
			<div class="form-group has-feedback has-feedback-left">
				<input type="text" class="form-control input-lg" placeholder="Username" name="register[username]">
				<div class="form-control-feedback">
					<i class="icon-user text-muted"></i>
				</div>
			</div>

			<div class="form-group has-feedback has-feedback-left">
				<input type="password" class="form-control input-lg" placeholder="Password" name="register[password]">
				<div class="form-control-feedback">
					<i class="icon-lock2 text-muted"></i>
				</div>
			</div>
			<div class="form-group has-feedback has-feedback-left">
				<input type="password" class="form-control input-lg" placeholder="Retype Password" name="register[repassword]">
				<div class="form-control-feedback">
					<i class="icon-lock2 text-muted"></i>
				</div>
			</div>
			<div class="form-group">
				<button type="submit" class="btn bg-blue btn-block btn-lg">Register <i class="icon-arrow-right14 position-right"></i></button>
			</div>
			<div class="content-divider text-muted form-group"><span>Already have an account?</span></div>
			<a href="<?= base_url('auth/login') ?>" class="btn bg-slate btn-block btn-lg content-group">Login</a>
			<span class="help-block text-center">
				By continuing, you're confirming that you've read and agree to our <a href="#">Terms and Conditions</a> and <a href="#">Cookie Policy</a>
			</span>
		</div>
	</form>
</section>